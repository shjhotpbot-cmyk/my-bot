from telethon import TelegramClient, events, Button
import re
import os

# ==== LOAD FROM .env ====
api_id = int(os.getenv("API_ID"))
api_hash = os.getenv("API_HASH")

# ==== CHANNEL / GROUP SETUP ====
file_source_1 = -1002445761009         # File Channel 1
file_forward_to_1 = -1002638925345     # Your Channel

file_source_2 = -1002360296508         # File Channel 2 (NEW)
file_forward_to_2 = -1002638925345     # Forward to same channel

otp_source_1 = -1001748669476          # OTP Group 1
otp_forward_to_1 = -1002780766214      # Your OTP Group

otp_source_2 = -1002044564008          # OTP Group 2 (NEW)
otp_forward_to_2 = -1002780766214      # Forward to same OTP group

# ==== CUSTOM LINKS ====
your_group_link = "https://t.me/SHJH_OTP_InsTanT1"
your_channel_link = "https://t.me/SHJH_OTP_InsTanT"

client = TelegramClient('user_forward_session', api_id, api_hash)

# ✅ FILE FORWARDING (both sources)
@client.on(events.NewMessage(chats=[file_source_1, file_source_2]))
async def forward_file(event):
    if event.file:
        caption = event.raw_text or ""
        lines = caption.splitlines()
        cleaned_lines = [
            re.sub(r'(@\w+|https?://t\.me/\S+|t\.me/\S+|telegram\.me/\S+)', '', line)
            for line in lines
            if "OTP : JOIN HERE" not in line
        ]
        cleaned_caption = "\n".join(cleaned_lines).strip()

        await client.send_file(
            file_forward_to_1,  # Both sources forward to same channel
            file=event.media,
            caption=cleaned_caption,
            buttons=[Button.url("🔐 OTP Group Join Here", your_group_link)]
        )

# ✅ OTP FORWARDING (both sources)
@client.on(events.NewMessage(chats=[otp_source_1, otp_source_2]))
async def forward_otp(event):
    text = event.raw_text
    if re.search(r'\b(\d{4,8})\b', text):
        await client.send_message(
            otp_forward_to_1,  # Both sources forward to same OTP group
            message=text,
            buttons=[Button.url("📢 Main Channel", your_channel_link)]
        )

print("✅ Forwarding system is running...")
client.start()
client.run_until_disconnected()